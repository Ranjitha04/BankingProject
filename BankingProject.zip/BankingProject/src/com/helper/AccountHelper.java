package com.helper;

public class AccountHelper {

	static int idCount = 0;
	static long accountNumber = 1000000;
	
	public static long getAccountNumberIncrement() {	
		return accountNumber++;
	}

	public static int getIdIncrement() {
		return idCount++;
	}

}
