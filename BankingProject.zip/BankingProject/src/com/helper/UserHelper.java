package com.helper;

public class UserHelper {
	static int count = 0;

	public static int getIncrement() {
		return count++;
	}

}
