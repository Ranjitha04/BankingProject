package com.controller;

import javax.servlet.http.HttpServlet;

public class AccountController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
