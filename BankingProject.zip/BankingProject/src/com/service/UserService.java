package com.service;

import com.dao.UserDao;
import com.helper.UserHelper;
import com.model.User;

public class UserService {
	UserDao userDao;

	public void saveUser(User user) {
		userDao = new UserDao();
		
		user.setUserId(UserHelper.getIncrement());
		userDao.saveUser(user);
		
	}

}
