package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ConectionManager;
import com.helper.AccountHelper;
import com.helper.UserHelper;
import com.model.User;

public class AccountDao {
	
	Connection conn;
	
	public int saveAccount(int userId) {
		conn = ConectionManager.getConnection();
		String query = "insert into account(accountId, accountNumber, balance, userId) "
				+ "  values(?,?,?,?)";
		
		try {
		    PreparedStatement stmt = conn.prepareStatement(query);
		    stmt.setInt(1, AccountHelper.getIdIncrement());
		    stmt.setLong(2, AccountHelper.getAccountNumberIncrement());
		    stmt.setDouble(3, 0.0);
		    stmt.setInt(4, userId);
		    
		    if(stmt.executeUpdate() == 0) {
		    	return 0;
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 1;
	}

}
