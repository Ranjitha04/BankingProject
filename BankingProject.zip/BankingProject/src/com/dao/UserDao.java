package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ConectionManager;
import com.helper.UserHelper;
import com.model.User;

public class UserDao {

	Connection conn;
	
	public String saveUser(User user) {
		conn = ConectionManager.getConnection();
		
		String query = "insert into user(userId, name, mobileNumber, password) "
				+ "  values(?,?,?,?)";
		
		try {
		    PreparedStatement stmt = conn.prepareStatement(query);
		 
		    stmt.setInt(1, user.getUserId());
		    stmt.setString(2, user.getName());
		    stmt.setString(3, user.getMobileNumber());
		    stmt.setString(4, user.getPassword());
		    
		    if(stmt.executeUpdate() == 0) {
		    	return "Registration Failed";
		    }
		    AccountDao accountDao = new AccountDao();
		    
		    if(accountDao.saveAccount(user.getUserId()) == 0)
		    	return "Registration Failed";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Registration SuccessFull";
	}

}
